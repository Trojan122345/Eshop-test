package cz.osu.ooprproj;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OoprProjApplication {

    public static void main(String[] args) {
        SpringApplication.run(OoprProjApplication.class, args);
    }

}
