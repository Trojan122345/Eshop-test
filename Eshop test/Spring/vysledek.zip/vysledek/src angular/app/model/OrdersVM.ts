import {OrderAddrVM} from './OrderAddrVM';

export class OrdersVM {
  id: number;
  customerId: number;
  address: OrderAddrVM;
  orderdate: Date;
}
