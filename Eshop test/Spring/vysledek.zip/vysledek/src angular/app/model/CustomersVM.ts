export class CustomersVM {
  id: number;
  name: string;
  surname: string;
  email: string;
  username: string;
  passwordHash: string;
  admin: boolean;
}
