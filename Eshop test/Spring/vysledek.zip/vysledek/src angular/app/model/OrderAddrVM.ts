export class OrderAddrVM {
  city: string;
  street: string;
  psc: string;
}
