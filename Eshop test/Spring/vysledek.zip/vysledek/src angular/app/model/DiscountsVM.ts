export class DiscountsVM {
  id: number;
  productId: number;
  percent: number;
  datefrom: Date;
  dateto: Date;
}
