export class OrdersProductsVM {
  id: number;
  orderID: number;
  productID: number;
  amount: number;
  pricePerProduct: number;
}
